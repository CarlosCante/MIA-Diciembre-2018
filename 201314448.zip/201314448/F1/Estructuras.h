#ifndef ESTRUCTURAS_H_INCLUDED
#define ESTRUCTURAS_H_INCLUDED
#include <time.h>

typedef struct MBR MBR;
typedef struct Particion Particion;
typedef struct EBR EBR;
typedef struct NodoParticion NodoParticion;
typedef struct ListaMomunt ListaMomunt;

struct NodoParticion
{
    char Path[100];
    char Nombre[16];
    char ID[5];
    int inicio;
    NodoParticion *siguiente;
    NodoParticion *anterior;
};

struct ListaMomunt
{
    int cantidad;
    NodoParticion *primero;
    NodoParticion *ultimo;
};

struct EBR
{
    char Status;
    char Ajuste;
    int Inicio;
    int Tamanio;
    int Ap_Sig;
    char Nombre[16];
};

struct Particion
{
    char Status;
    char Tipo;
    char Ajuste;
    int Inicio;
    int Tamanio;
    char Nombre[16];
};

struct MBR
{
    int Tamanio;
    char FechaCreacion[17];
    int disk_asignature;
    char Ajuste;
    Particion Particiones[4];
};

/**Area de structs del comando mount, conta del nodo de la lista y la lista en si de las particiones montadas**/




#endif // ESTRUCTURAS_H_INCLUDED
